<script setup>
import { ref, computed } from 'vue';
import { useRouter, RouterView } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import { MENU_FEATURES } from '@/config/menuFeatures';
import * as Icons from 'lucide-vue-next';

const authStore = useAuthStore();
const router = useRouter();

const isDrawerOpen = ref(false);
const activeDropdown = ref(null);

const menuItems = computed(() => {
  return MENU_FEATURES
    .map(item => {
      // filtra submenus
      const dropdown = item.dropdown
        ? item.dropdown.filter(sub =>
            authStore.hasPermission(sub.permission)
          )
        : null;

      return {
        ...item,
        icon: Icons[item.icon],
        dropdown
      };
    })
    .filter(item => {
      // item simples
      if (!item.dropdown) {
        return authStore.hasPermission(item.permission);
      }
      // item com dropdown
      return item.dropdown.length > 0;
    });
});

const toggleDropdown = (name) => {
  activeDropdown.value =
    activeDropdown.value === name ? null : name;
};

const handleNavigation = (route) => {
  router.push(route);
  isDrawerOpen.value = false;
};
</script>

<template>
  <div class="min-h-screen bg-gray-100 flex">

    <main class="flex-1">
      <RouterView />
    </main>

    <!-- BOTÃO MOBILE -->
    <button
      class="fixed bottom-6 right-6 z-30 bg-blue-600 text-white p-4 rounded-full shadow-lg lg:hidden"
      @click="isDrawerOpen = true"
    >
      <component :is="Icons.Menu" :size="22" />
    </button>

    <!-- DRAWER -->
    <div
      v-if="isDrawerOpen"
      class="fixed inset-0 z-40"
      @click.self="isDrawerOpen = false"
    >
      <div class="absolute inset-0 bg-black/50"></div>

      <aside class="absolute right-0 top-0 h-full w-64 bg-gray-900 text-white p-4">
        <nav class="space-y-2">

          <!-- 🚫 SEM PERMISSÕES -->
          <div
            v-if="menuItems.length === 0"
            class="text-center text-gray-400 text-sm mt-10"
          >
            Cargo sem permissões
          </div>

          <!-- MENU NORMAL -->
          <div v-for="item in menuItems" :key="item.name">

            <!-- COM DROPDOWN -->
            <div
              v-if="item.dropdown"
              @click="toggleDropdown(item.name)"
              class="flex justify-between p-2 hover:bg-gray-800 cursor-pointer"
            >
              <span class="flex gap-2">
                <component :is="item.icon" :size="18" />
                {{ item.name }}
              </span>
              <component
                :is="activeDropdown === item.name
                  ? Icons.ChevronDown
                  : Icons.ChevronRight"
                :size="16"
              />
            </div>

            <div
              v-if="item.dropdown && activeDropdown === item.name"
              class="ml-4"
            >
              <div
                v-for="sub in item.dropdown"
                :key="sub.name"
                @click="handleNavigation(sub.route)"
                class="p-2 text-sm hover:bg-gray-700 cursor-pointer"
              >
                {{ sub.name }}
              </div>
            </div>

            <!-- ITEM SIMPLES -->
            <div
              v-else
              @click="handleNavigation(item.route)"
              class="flex gap-2 p-2 hover:bg-gray-800 cursor-pointer"
            >
              <component :is="item.icon" :size="18" />
              {{ item.name }}
            </div>

          </div>
        </nav>
      </aside>
    </div>
  </div>
</template>
