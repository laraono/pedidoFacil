<script setup>
import { useAuthStore } from '@/stores/auth';
import { PERMISSIONS } from '@/utils/permissions';

import CardEstabelecimento from '@/components/dashboard/ConfigEstablishmentCard.vue';
import CardCargos from '@/components/dashboard/ConfigRolesCard.vue';
import CardCardapio from '@/components/dashboard/ConfigMenuCard.vue';

const auth = useAuthStore();
</script>

<template>
  <div class="dashboard">
    <CardEstabelecimento v-if="auth.hasPermission(PERMISSIONS.CONFIGURACAO)" />
    <CardCargos v-if="auth.hasPermission(PERMISSIONS.CONFIGURACAO)" />
    <CardCardapio v-if="auth.hasPermission(PERMISSIONS.CONFIGURACAO)" />

    <p
      v-if="!auth.hasPermission(PERMISSIONS.CONFIGURACAO)"
      class="text-gray-500 text-center mt-10"
    >
      Cargo sem permissões
    </p>
  </div>
</template>