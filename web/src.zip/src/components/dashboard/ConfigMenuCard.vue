<script setup>
import { useRouter } from 'vue-router';
import { Utensils } from 'lucide-vue-next';

const router = useRouter();
</script>

<template>
  <div class="card">
    <h3><Utensils /> Cardápio</h3>
    <p>Configure produtos</p>
    <button @click="router.push('/app/settings/menu')">
      Editar
    </button>
  </div>
</template>
