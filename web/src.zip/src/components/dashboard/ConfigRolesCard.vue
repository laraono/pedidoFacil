<script setup>
import { useRouter } from 'vue-router';
import { Briefcase } from 'lucide-vue-next';

const router = useRouter();
</script>

<template>
  <div class="card">
    <h3><Briefcase /> Cargos e Permissões</h3>
    <p>Gerencie funcionários</p>
    <button @click="router.push('/app/settings/roles')">
      Editar
    </button>
  </div>
</template>
