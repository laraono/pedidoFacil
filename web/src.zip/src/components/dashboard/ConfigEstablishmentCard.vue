<script setup>
import { useRouter } from 'vue-router';

const router = useRouter();

function go() {
  router.push('/app/settings/establishment');
}
</script>

<template>
  <div class="card" @click="go">
    <h3>Estabelecimento</h3>
    <p>Configurações do estabelecimento</p>
  </div>
</template>