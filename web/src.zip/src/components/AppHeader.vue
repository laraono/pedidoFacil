<script setup>
import { computed } from 'vue';
import { useAuthStore } from '@/stores/auth';
import { LogOut } from 'lucide-vue-next';
import { useRouter } from 'vue-router';

const authStore = useAuthStore();
const router = useRouter();

const userName = computed(() => authStore.user?.name || '');
const roleName = computed(() => authStore.role?.name || '');
const establishmentName = 'Restaurante XPTO';

const logout = () => {
  authStore.logout();
  router.push('/login');
};
</script>

<template>
  <header
    v-if="authStore.isAuthenticated"
    class="bg-blue-600 text-white px-6 py-3 flex justify-between items-center"
  >
    <div>
      <h1 class="font-bold text-lg">{{ establishmentName }}</h1>
      <span class="text-xs opacity-80">{{ roleName }}</span>
    </div>

    <div class="flex items-center gap-4">
      <span class="text-sm">{{ userName }}</span>
      <button
        @click="logout"
        class="hover:bg-blue-700 p-2 rounded"
      >
        <LogOut :size="18" />
      </button>
    </div>
  </header>
</template>
