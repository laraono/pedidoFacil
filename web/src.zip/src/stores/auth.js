// stores/auth.js
import { defineStore } from 'pinia';
import { loginMock, logoutMock } from '@/mock/authmock';
import { getRolesMock } from '@/mock/rolesmock';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: null,
    roles: [],
    isAuthenticated: false
  }),

  actions: {
    async login({ email, senha }) {
      const user = loginMock(email, senha);

      this.user = user;
      this.isAuthenticated = true;
      this.roles = await getRolesMock();
    },

    loadSession() {
      const user = JSON.parse(localStorage.getItem('user'));
      if (!user) return;

      this.user = user;
      this.roles = JSON.parse(localStorage.getItem('roles')) || [];
      this.isAuthenticated = true;
    },

    hasPermission(permission) {
      if (!this.user || !this.user.roleId) return false;

      const role = this.roles.find(r => r.id === this.user.roleId);
      if (!role) return false;

      return role.permissions.includes(permission);
    },

    logout() {
      logoutMock();
      localStorage.clear();
      this.user = null;
      this.roles = [];
      this.isAuthenticated = false;
    }
  }
});
