import { PERMISSIONS } from '@/utils/permissions';

export const MENU_FEATURES = [
  {
    name: 'Pedidos',
    icon: 'Utensils',
    route: '/app/orders/queue',
    permission: PERMISSIONS.CRIAR_PEDIDO
  },
  {
    name: 'Configurações',
    icon: 'Settings',
    permission: PERMISSIONS.CONFIGURACAO,
    dropdown: [
      {
        name: 'Restaurante',
        route: '/app/settings/establishment',
        permission: PERMISSIONS.CONFIGURACAO
      },
      {
        name: 'Funcionários',
        route: '/app/settings/employees',
        permission: PERMISSIONS.CONFIGURACAO
      }
    ]
  }
];
